# Path B-3 — V.E Donut FT Replicate 배포 패키지

> **자족적 패키지** — adapter ckpt 포함 (별도 다운로드 불필요)
> **상세 가이드**: `../../SERVER_MANUAL_path_b3_v_e_donut_ft.md`

---

## 폴더 구성

```
replicate_v_e_donut_ft_path_b3/
├── README.md                       ← 본 파일
├── cog.yaml                        ← Replicate Cog config (torch 2.3.1 + transformers + peft)
├── predict.py                      ← Donut + LoRA inference Predictor
└── adapter/                        ← V.E LoRA ckpt (포함됨, 약 18 MB)
    ├── adapter_config.json         (1.1 KB, LoRA r=32 alpha=64)
    ├── adapter_model.safetensors   (14 MB) ⭐
    ├── processor_config.json       (554 B, DonutProcessor 설정)
    ├── tokenizer.json              (3.9 MB, V.E special tokens 포함)
    └── tokenizer_config.json       (1.5 KB)
```

---

## 빠른 사용법 (서버 작업자)

```bash
cd server/cloud_deploy/replicate_v_e_donut_ft_path_b3/

# 1. Adapter 검증 (이미 포함됨 확인)
ls -lh adapter/  # 5개 파일, 약 18 MB

# 2. 로컬 cog build (사전 검증, Replicate 안 감)
cog build

# 3. (선택) 로컬 cog predict (GPU 있을 경우)
cog predict -i image=@test.png -i region=titleblock

# 4. Replicate 배포 (T4 GPU 권장)
cog push r8.im/<your-username>/v-e-donut-ft-pathb3-demo
```

---

## 입력 / 출력

### 입력
- `image`: 도면 PNG/JPG
- `region`: titleblock / view / notes / measure / gdt / roughness / **all** (default: titleblock)
- `rfq_id`: string (default: RFQ-DEMO)
- `quantity`: int (default: 100)

### 출력 (region=titleblock 예시)
```json
{
  "drawing_id": "sample_00000",
  "schema_version": "v_e_donut_ft_pathb3",
  "region": "titleblock",
  "inference_seconds": 3.2,
  "extracted": {
    "Drawing_No": "TEP410-0601-01",
    "Material": "SUS304",
    "Mass": "54Kg",
    ...
  }
}
```

---

## 모델 정보

| 항목 | 값 |
|---|---|
| Base | `naver-clova-ix/donut-base` |
| LoRA | r=32, alpha=64, target_modules=[fc2, out_proj, v_proj, k_proj, fc1, q_proj] |
| 학습 source | V.E annotation 1063 sample (Gemini 2.5 Flash, 93% PASS Pro judge) |
| 학습 epoch | 15 (best val loss 0.66) |
| Image size | 960 × 1280 (h × w) |
| Inference precision | bfloat16 |

---

## D-099 검증 metric (실측)

| Metric | 값 |
|---|---|
| Drawing_No char_acc (영문) | **67.1%** ⭐ |
| view symbol_rate (GDT/roughness) | **32.6%** (V.B ⊥ collapse 7% 의 5배 ⭐) |
| titleblock match_rate (15 fields) | 13.9% (한자 OCR ceiling) |
| titleblock char_acc | 25.4% |
| Schema 학습 | 100% |

---

## GPU 권장 (Replicate hardware)

| GPU | 메모리 | 비용 | 권장도 |
|---|---|---|---|
| **T4** | 16 GB | $0.000225/sec | ⭐ default |
| L4 | 24 GB | $0.000555/sec | 안정 옵션 |
| A40 | 48 GB | $0.000725/sec | overkill |

→ **T4 권장**. Sample 당 inference 3~5초 = $0.001/sample.

---

## 주의 사항

1. **adapter/ 폴더 변경 금지** — cog build 시 image 에 포함됨
2. **base model `naver-clova-ix/donut-base`** = cord-v2 아님 (주의)
3. **transformers==4.45.2 + peft==0.13.0** 정확 버전 고정 (cog.yaml)
4. **vLLM 미사용** — Path B-2 의 grouped GEMM op 호환 issue 회피
5. **한자 영역 정확도 낮음** (Title/Material/Engineer 등) — V.F Hybrid 완료 시 swap 권장

---

## 참고 문서

- 상세 setup / push / 검증 / IMMA 통합: **`../../SERVER_MANUAL_path_b3_v_e_donut_ft.md`** ⭐
- V.E phase 박제 baseline: `../../../PROJECT_HANDOFF_ver.E.md`
- V.B Replicate 디버그 가이드 (Path A/C/B 시도 history): `../../../replicate_debug_package/V_B_REPLICATE_FIX_GUIDE_FOR_VLM_TEAM.md`
- Path B-2 (Pretrained Qwen2-VL-7B) 비교 baseline: `../replicate_v_b_demo_v1/` (기존)

---

End of README
