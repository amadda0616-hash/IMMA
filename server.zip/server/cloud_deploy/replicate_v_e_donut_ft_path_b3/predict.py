"""
predict.py — Path B-3 (V.E Donut FT v2 + LoRA r=32 adapter)

V.E Donut FT cog Predictor
- 입력: 도면 PNG/JPG + region (titleblock/view/notes/measure/gdt/roughness) + rfq_id + quantity
- 출력: V.E annotation schema JSON (region 별)
- 모델: naver-clova-ix/donut-base + V.E LoRA adapter (best_epoch15_val0.6596)

설계:
- Donut VisionEncoderDecoderModel + PEFT LoRA (custom V.E FT)
- 신규 학습 X — best_epoch15 ckpt 그대로 활용
- 6 task_start_token: <s_titleblock>, <s_view>, <s_notes>, <s_measure>, <s_gdt>, <s_roughness>
- region 별 inference (단일 image → 선택 region 만 OCR + JSON)
- Image size: 960×1280 (V.E 학습 default)

V.E D-099 검증 metric:
- titleblock match_rate 13.9% / char_acc 25.4%
- view symbol_rate 32.6% (V.B ⊥ collapse 7% 의 5배 ⭐)
- Drawing_No char_acc 67.1% (영문 강함)
- Schema 100% 학습 (modules_to_save 효과)

테스트:
    cd server/cloud_deploy/replicate_v_e_donut_ft_path_b3/
    cog build
    cog predict -i image=@test.png -i region=titleblock
"""

import json
import os
import re
import time
import uuid
from pathlib import Path as LocalPath
from typing import Any, Optional

from cog import BasePredictor, Input, Path
from PIL import Image
import torch
from transformers import VisionEncoderDecoderModel, DonutProcessor
from peft import PeftModel


# ============================================================
# Config (V.E donut_ft_ver.E.py 기반)
# ============================================================

BASE_MODEL = "naver-clova-ix/donut-base"
ADAPTER_DIR = "./adapter"  # cog build 시 ckpt 복사 (manual 참조)

# Task tokens (V.A donut_numerical.yaml 3종 + V.E 신규 3종)
TASK_TOKENS = {
    "titleblock": "<s_titleblock>",
    "view":       "<s_view>",
    "notes":      "<s_notes>",
    "measure":    "<s_measure>",
    "gdt":        "<s_gdt>",
    "roughness":  "<s_roughness>",
}

# Image preprocessing default (V.E 학습 시점)
IMAGE_HEIGHT = 960
IMAGE_WIDTH = 1280

# Generation
DEFAULT_MAX_NEW_TOKENS = 768


# ============================================================
# Predictor
# ============================================================

class Predictor(BasePredictor):
    def setup(self):
        """V.E Donut FT 로딩 (Donut base + LoRA adapter)."""
        print(f"[setup] Loading base: {BASE_MODEL}")
        t0 = time.time()

        # 1. DonutProcessor (학습 후 tokenizer 사용 — adapter 폴더에 저장됨)
        self.processor = DonutProcessor.from_pretrained(ADAPTER_DIR)

        # 2. Base VisionEncoderDecoderModel
        base_model = VisionEncoderDecoderModel.from_pretrained(
            BASE_MODEL,
            torch_dtype=torch.bfloat16,
            low_cpu_mem_usage=True,
        )

        # 3. tokenizer 의 special tokens 추가 (V.E 학습 시 추가된 것)
        # adapter 의 tokenizer 가 이미 갖고 있음 → embedding resize 필요
        if len(self.processor.tokenizer) > base_model.decoder.config.vocab_size:
            base_model.decoder.resize_token_embeddings(len(self.processor.tokenizer))

        # 4. PEFT LoRA adapter 로드
        print(f"[setup] Loading PEFT adapter: {ADAPTER_DIR}")
        self.model = PeftModel.from_pretrained(
            base_model,
            ADAPTER_DIR,
            torch_dtype=torch.bfloat16,
        )
        self.model.eval()

        # 5. Device 이동
        if torch.cuda.is_available():
            self.model = self.model.to("cuda")

        # Generation config
        self.model.config.pad_token_id = self.processor.tokenizer.pad_token_id
        self.model.config.eos_token_id = self.processor.tokenizer.eos_token_id

        print(f"[setup] Loaded in {time.time() - t0:.1f}s")
        print(f"[setup] Device: {self.model.device}, dtype: {next(self.model.parameters()).dtype}")
        print(f"[setup] Tokenizer vocab size: {len(self.processor.tokenizer)}")

    def predict(
        self,
        image: Path = Input(description="도면 PNG/JPG 이미지"),
        region: str = Input(
            default="titleblock",
            description="추출 region (titleblock / view / notes / measure / gdt / roughness)",
            choices=["titleblock", "view", "notes", "measure", "gdt", "roughness", "all"],
        ),
        rfq_id: str = Input(default="RFQ-DEMO", description="RFQ ID"),
        quantity: int = Input(default=100, description="수량"),
    ) -> dict:
        """V.E Donut FT inference: image + region → JSON."""
        t_start = time.time()

        # 1. Image load + preprocess
        image_path = str(image)
        img = Image.open(image_path).convert("RGB")
        w, h = img.size

        m = re.search(r"sample_\d+", LocalPath(image_path).name)
        drawing_id = m.group(0) if m else f"draw_{uuid.uuid4().hex[:8]}"

        # 2. region 분기
        if region == "all":
            results = {}
            for r in ["titleblock", "view", "notes"]:
                results[r] = self._infer_region(img, r)
            extracted = results
        else:
            extracted = self._infer_region(img, region)

        elapsed = time.time() - t_start

        return {
            "drawing_id": drawing_id,
            "image_size": [w, h],
            "schema_version": "v_e_donut_ft_pathb3",
            "rfq_id": rfq_id,
            "quantity": quantity,
            "model_id": f"{BASE_MODEL} + V.E LoRA r=32 adapter (best_epoch15)",
            "region": region,
            "inference_seconds": round(elapsed, 2),
            "extracted": extracted,
        }

    def _infer_region(self, img: Image.Image, region: str) -> dict:
        """단일 region inference."""
        # Pixel preprocessing (DonutProcessor: 960×1280)
        pixel_values = self.processor(
            img,
            return_tensors="pt",
        ).pixel_values.to(self.model.device, dtype=torch.bfloat16)

        # Decoder input: task_start_token (region 별)
        task_token = TASK_TOKENS.get(region, "<s_titleblock>")
        decoder_input_ids = self.processor.tokenizer(
            task_token,
            add_special_tokens=False,
            return_tensors="pt",
        ).input_ids.to(self.model.device)

        # Generate
        with torch.no_grad():
            outputs = self.model.generate(
                pixel_values=pixel_values,
                decoder_input_ids=decoder_input_ids,
                max_new_tokens=DEFAULT_MAX_NEW_TOKENS,
                pad_token_id=self.processor.tokenizer.pad_token_id,
                eos_token_id=self.processor.tokenizer.eos_token_id,
                use_cache=True,
                bad_words_ids=[[self.processor.tokenizer.unk_token_id]],
                return_dict_in_generate=True,
            )

        # Decode (special tokens 보존 — XML-like format)
        sequence = self.processor.batch_decode(outputs.sequences)[0]

        # Special tokens 제거 (eos, pad)
        sequence = sequence.replace(self.processor.tokenizer.eos_token, "")
        sequence = sequence.replace(self.processor.tokenizer.pad_token, "")
        sequence = re.sub(r"<.s_\w+>", "", sequence)  # </s_xxx> 제거

        # XML-like → JSON 파싱
        return self._parse_donut_output(sequence, region)

    def _parse_donut_output(self, text: str, region: str) -> dict:
        """
        Donut XML-like output → JSON parsing.
        형식: <s_<region>><s_field>VALUE</s_field>...
        """
        # 1. region tag 제거
        text = text.replace(f"<s_{region}>", "").strip()

        # 2. <s_field>VALUE 패턴 추출
        result = {}
        # field 별 추출 (greedy match)
        for m in re.finditer(r"<s_(\w+)>([^<]*?)(?=<s_\w+>|$)", text):
            field = m.group(1)
            value = m.group(2).strip()
            if value and value != "":
                # nested field (view 의 measures/gdt/roughness 등)
                if field in result:
                    if isinstance(result[field], list):
                        result[field].append(value)
                    else:
                        result[field] = [result[field], value]
                else:
                    result[field] = value
        return result
