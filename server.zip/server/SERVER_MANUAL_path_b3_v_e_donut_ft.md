# 서버 작업 Manual — V.E Donut FT Path B-3 (Replicate cog 배포)

> **작성**: 2026-05-13
> **대상 서버팀**: V.B Replicate Path B-2 성공한 팀원 (transformers + JSON repair 경험)
> **목적**: V.E D-099 학습 완료 ckpt 를 Replicate 에 배포 → IMMA 서버 cloud_client 통합

---

## 0. 빠른 요약

```
Path B-3 = V.E Donut FT v2 ckpt (custom 학습) 활용 cog 배포

vs 기존 Path B-2 (Qwen2-VL-7B Pretrained):
  - 학습 효과: ❌ Pretrained zero-shot → ✅ V.E annotation 1063 sample 학습
  - View symbol: 미측정 → 32.6% (V.B ⊥ collapse 7% 의 5배 ⭐)
  - Drawing_No char_acc: 미측정 → 67.1%
  - Schema 학습: 100% (modules_to_save 효과)
  - 비용 (Replicate): A40 $0.0023/sec → T4 $0.000225/sec (10배 저렴)
  - Inference: 17초 → 3~5초 (5x 빠름)

위치:
  cog 패키지: server/cloud_deploy/replicate_v_e_donut_ft_path_b3/
  학습 ckpt: colab_sync/outputs/v_e_donut_ft/checkpoints/best_epoch15_val0.6596/
```

---

## 1. 학습 ckpt 정보 (서버팀이 받아야 할 자산)

### 1.1 ckpt 위치 및 파일

```
colab_sync/outputs/v_e_donut_ft/checkpoints/best_epoch15_val0.6596/
├── adapter_config.json          (LoRA 설정)
├── adapter_model.safetensors    ⭐ (13.6 MB, V.E LoRA adapter)
├── processor_config.json        (DonutProcessor 설정)
├── tokenizer.json               (V.E 학습 시 추가된 special tokens 포함)
├── tokenizer_config.json
└── README.md
```

### 1.2 학습 정보

| 항목 | 값 |
|---|---|
| Base model | `naver-clova-ix/donut-base` (cord-v2 아님) |
| LoRA | r=32, alpha=64 |
| Target modules | fc2, out_proj, v_proj, k_proj, fc1, q_proj |
| Task type | SEQ_2_SEQ_LM |
| Image size | 960 × 1280 (height × width) |
| Special tokens (6 region) | `<s_titleblock>`, `<s_view>`, `<s_notes>`, `<s_measure>`, `<s_gdt>`, `<s_roughness>` |
| 학습 epoch | 15 (best val loss 0.6596) |
| Adapter version | peft 0.19.1 |

### 1.3 V.E annotation source

- 1063 sample (Gemini 2.5 Flash annotation, D-097)
- Pro LLM-as-a-judge 검증 93% PASS (D-097.3)

### 1.4 D-099 검증 결과 (실측)

| Metric | 값 | 비고 |
|---|---|---|
| titleblock match_rate (15 fields) | 13.9% | 한자 OCR ceiling |
| titleblock char_acc | 25.4% | |
| view symbol_rate | **32.6%** ⭐ | V.B ⊥ collapse 7% 의 5배 |
| view char_acc | 18.9% | noise mismatch |
| Drawing_No (영문) char_acc | **67.1%** ⭐ | 영문 강함 |
| Company_Name (한자) match | 0% | architecture ceiling |
| Schema 학습 | 100% | modules_to_save 효과 |

---

## 2. 폴더 구조 (cog 패키지)

```
server/cloud_deploy/replicate_v_e_donut_ft_path_b3/
├── cog.yaml                    ← Path B-3 cog config
├── predict.py                  ← V.E Donut FT inference (transformers + peft)
├── adapter/                    ⭐ ckpt 복사 위치 (수동, §3 참조)
│   ├── adapter_config.json
│   ├── adapter_model.safetensors
│   ├── processor_config.json
│   ├── tokenizer.json
│   └── tokenizer_config.json
└── (선택) test.png             ← 사전 검증용 sample 도면
```

---

## 3. Setup (서버팀 작업 — 약 20분)

### 3.1 Adapter ckpt — **이미 포함됨** ✅ (별도 복사 불필요)

cog 패키지 폴더 (`server/cloud_deploy/replicate_v_e_donut_ft_path_b3/`) 안에 `adapter/` 폴더가 **이미 포함되어 전달**됩니다.

```bash
cd server/cloud_deploy/replicate_v_e_donut_ft_path_b3/

# 검증 (5개 파일 + 약 18 MB 확인)
ls -lh adapter/
# 기대 출력:
#   adapter_config.json (~1.1 KB)
#   adapter_model.safetensors (14 MB) ⭐
#   processor_config.json (~554 B)
#   tokenizer.json (~3.9 MB)
#   tokenizer_config.json (~1.5 KB)
```

만약 `adapter/` 폴더가 없거나 비어있는 경우에만 아래 명령으로 복사 (백업용):

```bash
# 원본 위치 (cowork 작업 폴더 — 보통 서버팀에는 없음)
SRC=../../../colab_sync/outputs/v_e_donut_ft/checkpoints/best_epoch15_val0.6596
mkdir -p adapter
cp $SRC/adapter_config.json adapter/
cp $SRC/adapter_model.safetensors adapter/
cp $SRC/processor_config.json adapter/
cp $SRC/tokenizer.json adapter/
cp $SRC/tokenizer_config.json adapter/
```

### 3.2 사전 검증 (로컬 cog build, 비용 0)

```bash
# Cog version 확인 (1.0+ 권장, Path B-2 와 동일)
cog --version

# Build (Docker image 생성, Replicate 안 감)
cog build

# 성공 시:
#   Adding labels to image...
#   Image built as cog-replicate_v_e_donut_ft_path_b3
```

### 3.3 로컬 cog predict (선택, GPU 있으면)

```bash
# 테스트 image 준비
cp ../../../colab_sync/dataset/JP/images/sample_00000_*.jpg test.png

# 5 region 각각 검증
cog predict -i image=@test.png -i region=titleblock -i rfq_id=TEST -i quantity=100
cog predict -i image=@test.png -i region=view
cog predict -i image=@test.png -i region=notes
cog predict -i image=@test.png -i region=all  # 모든 region 통합

# 정상:
#   {
#     "drawing_id": "sample_00000",
#     "region": "titleblock",
#     "extracted": {"Drawing_No": "...", "Material": "...", ...},
#     "inference_seconds": 3.2
#   }
```

---

## 4. Replicate 배포 (push)

### 4.1 GPU type 변경 (Replicate dashboard)

기존 Path B-2 model 의 hardware 변경:
```
기존: A40 (48GB, $0.0023/sec)
변경: T4 (16GB, $0.000225/sec) ⭐ (10배 저렴)
   또는 L4 (24GB, $0.000555/sec) (안정 옵션)
```

dashboard URL: https://replicate.com/<user>/<model>/settings

### 4.2 Push (새 model 또는 기존 model 의 새 version)

```bash
# 옵션 A: 기존 V.B Path B-2 model 의 새 version (덮어쓰기)
cog push r8.im/rnjsxodms12-star/qwen3vl-v-b-demo-v1
# → 새 version hash 생성 (Path B-3)

# 옵션 B: V.E 전용 새 model 생성 (권장 — 분리)
# 1. Replicate dashboard 에서 새 private model 생성:
#    이름: v-e-donut-ft-pathb3-demo
#    hardware: T4 또는 L4
# 2. Push:
cog push r8.im/<your-username>/v-e-donut-ft-pathb3-demo
```

### 4.3 Push 진행 시간

- Image build: 5~15분 (transformers + torch + peft download)
- Push to Replicate registry: 5~10분 (image + adapter 13.6 MB 포함)
- Replicate setup (worker 생성): 1~3분 (Path B-2 보다 빠름, 모델 작음)

---

## 5. Run 검증 (Replicate Playground)

### 5.1 입력

| 항목 | 값 |
|---|---|
| image | 도면 PNG/JPG 업로드 또는 URL |
| region | titleblock / view / notes / measure / gdt / roughness / all |
| rfq_id | RFQ-TEST |
| quantity | 100 |

### 5.2 성공 기대 출력 (region=titleblock)

```json
{
  "drawing_id": "sample_00000",
  "image_size": [3365, 2077],
  "schema_version": "v_e_donut_ft_pathb3",
  "rfq_id": "RFQ-TEST",
  "quantity": 100,
  "model_id": "naver-clova-ix/donut-base + V.E LoRA r=32 adapter (best_epoch15)",
  "region": "titleblock",
  "inference_seconds": 3.2,
  "extracted": {
    "Drawing_No": "TEP410-0601-01",
    "Material": "SUS304",
    "Mass": "54Kg",
    "Scale": "1:1",
    ...
  }
}
```

### 5.3 실패 시 분석 표

| Replicate log 메시지 | 원인 | 대응 |
|---|---|---|
| `worker setup failed: ValueError: infer_schema(func)...` | torch op 호환 (Path B-2 문제 재발) | torch 버전 더 낮추기 (2.2.x) — 가능성 매우 낮음 |
| `OutOfMemoryError` | T4 16GB 부족 (드물게) | L4/A40 으로 변경 |
| `adapter not found` | §3.1 ckpt 복사 누락 | adapter/ 폴더 5개 파일 확인 |
| `OSError: Can't load tokenizer` | tokenizer.json 누락 | adapter/tokenizer.json 복사 확인 |
| `RuntimeError: Embedding mismatch` | base model embedding resize 미적용 | predict.py 의 resize_token_embeddings 라인 확인 |

---

## 6. IMMA 서버 통합

### 6.1 .env 설정 (Path B-2 기존 → Path B-3 swap)

```bash
# IMMA 서버 .env
V_E_DEMO_MODE=cloud
V_E_CLOUD_PROVIDER=replicate
V_E_CLOUD_API_TOKEN=r8_xxxxxxxxxxxxxxxxxxxxxxxxx
V_E_CLOUD_MODEL_VERSION=<path_b3 새 version hash>  ⭐ 변경
V_E_CLOUD_TIMEOUT=60  # Path B-2 의 120 → 60 (Path B-3 빠름)
```

### 6.2 cloud_client_ver_E.py 변경 (선택)

- Path B-3 의 schema 가 region 별 분리됨 (`region` parameter 추가)
- 기존 cloud_client 가 `region=all` 호출하면 모든 region 통합 결과 반환 (V.B schema 호환)
- 변경 최소화 가능

```python
# cloud_client_ver_E.py (개념 코드, 실제는 기존 코드 그대로 + region 파라미터만 추가)
result = replicate.run(
    "your/v-e-donut-ft-pathb3-demo:<version_hash>",
    input={
        "image": image_url,
        "region": "all",  # ⭐ 신규 필드 (default: titleblock)
        "rfq_id": rfq_id,
        "quantity": quantity,
    }
)
```

---

## 7. 비용 비교 (Path B-2 vs Path B-3)

| 항목 | Path B-2 (Qwen2-VL-7B Pretrained) | Path B-3 (V.E Donut FT) |
|---|---|---|
| GPU | A40 48GB | T4 16GB ⭐ |
| GPU 비용 | $0.0023/sec | $0.000225/sec ⭐ (10배 저렴) |
| Inference 시간 | 17초 | 3~5초 ⭐ (5x 빠름) |
| Sample 당 비용 | **$0.04** | **$0.001~0.0011** ⭐ (40배 저렴) |
| 1000 sample 비용 | $40 | **$1~1.1** ⭐ (40배 저렴) |
| 모델 학습 효과 | ❌ Pretrained zero-shot | ✅ V.E annotation 1063 sample 학습 |
| Schema 학습 | ❌ prompt 의존 | ✅ 100% 학습 (modules_to_save) |
| GDT 14종 | 미측정 | 32.6% (V.B 5배) ⭐ |

→ **Path B-3 가 비용 40배 저렴 + 정확도 (특정 영역) 향상**.

---

## 8. 정확도 한계 (사전 안내)

| 영역 | 정확도 | 비고 |
|---|---|---|
| Drawing_No (영문) | char_acc 67.1% | 영문 OCR 강점 ⭐ |
| view symbol (GDT/roughness) | 32.6% | V.B 5배 |
| titleblock (15 fields) | match 13.9% / char 25.4% | **한자 OCR ceiling** ⚠️ |
| Company_Name (한자) | 0% | architecture ceiling ⚠️ |
| view char_acc | 18.9% | noise mismatch |
| notes char_acc | 18.2% | |

→ **한자 영역 정확도 낮음**. 영문/symbol 위주로 demo 가능.

→ V.F Hybrid (D-104) 완료 시 한자 영역 추가 ckpt swap 가능 (Qwen3-VL-2B FT + Nemotron).

---

## 9. 향후 swap plan (V.F Hybrid)

```
[Phase 1] Path B-3 = V.E Donut FT 단독 (영문/symbol 강점)
    ↓ (V.F D-104 완료 시)
[Phase 2] V.F Hybrid 패키지 swap:
    - 영문/symbol → V.E Donut FT (Path B-3 ckpt 재사용)
    - 한자 → V.F Qwen3-VL-2B FT (Path B-3 + region routing)
    - 통합 → titleblock 13.9% → 55~75% 향상 기대
```

→ Path B-3 cog 패키지가 V.F Hybrid 의 base 가 됨. predict.py 의 region routing 만 확장 필요.

---

## 10. 체크리스트 (서버팀)

- [ ] §3.1 adapter/ 폴더 5개 파일 복사
- [ ] §3.2 cog build 통과 (로컬 검증)
- [ ] (선택) §3.3 cog predict 로컬 검증
- [ ] §4.1 Replicate hardware T4/L4 변경
- [ ] §4.2 cog push 성공
- [ ] §5.1 Playground 에서 image input → JSON output 확인
- [ ] §5.2 region=all 시 모든 region 통합 결과 확인
- [ ] §6.1 IMMA 서버 .env V_E_CLOUD_MODEL_VERSION 갱신
- [ ] (선택) §6.2 cloud_client_ver_E.py region 파라미터 추가
- [ ] V.B Path B-2 model 은 disable (중복 방지, 비용 통제)

---

## 11. 실패 시 ChatGPT 활용 prompt

```
[배경]
Replicate cog 환경에서 V.E Donut FT (Path B-3) 배포.
- base: naver-clova-ix/donut-base
- adapter: V.E LoRA r=32 (peft 0.19.1)
- transformers 4.45.2 + torch 2.3.1

[첨부]
- cog.yaml
- predict.py
- adapter_config.json
- 발생한 에러 로그

[질문]
1. cog build 또는 worker setup 에러 root cause?
2. Donut + PEFT LoRA inference 시 vocabulary embedding resize 정상?
3. DonutProcessor 의 task_start_token 사용법?
4. 만약 Path B-2 의 grouped GEMM op 에러 재발 시 해결책?
```

---

## 12. 비용 통제

- Path B-2 model 도 활성화 시 중복 비용 → **disable 필수**
- Path B-3 cog push 시 image build (~5~15분) 비용 0 (Replicate 무료)
- Run setup (worker 생성): T4 setup ~1~3분 = $0.04~0.12 (Path B-2 의 1/100)
- Inference: $0.001/sample (1000 sample = $1)

→ **테스트/시연 비용 부담 거의 없음**.

---

## 13. V.E phase ↔ V.F phase 관계 (참고)

| Phase | 상태 | 결과 |
|---|---|---|
| V.E (Donut FT) | ✅ D-099 완료 | titleblock 13.9% / view symbol 32.6% / Drawing_No 67.1% |
| V.F (Hybrid: Donut + Qwen3-VL-2B + Nemotron) | ⏳ D-100~D-105 진행 중 | 예상: titleblock 55~75% (한자 영역 보강) |

V.E ckpt = V.F Hybrid 의 영문/symbol 모듈 (Donut FT 그대로 재사용)
V.F 완료 시 → 한자 영역만 Qwen3-VL-2B FT 로 보강

---

## 14. 한 줄 요약

> **V.E Donut FT (best_epoch15) cog 배포 = T4 GPU + 3~5초 inference + Sample 당 $0.001 + V.E annotation 1063 sample 학습 효과**.
> Path B-2 (Qwen2-VL-7B Pretrained) 대비 비용 40배 절감 + 학습 효과 추가 (특히 영문/symbol).
> 한자 영역은 ceiling 잔존 → V.F Hybrid 완료 시 추가 swap.

---

End of manual
